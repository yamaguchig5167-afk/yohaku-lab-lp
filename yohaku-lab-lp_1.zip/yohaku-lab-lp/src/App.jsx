import { useState, useEffect, useRef } from "react";

const C = {
  washi:"#F4EFE4", washiDark:"#EAE3D2",
  ink:"#1A1914", inkLight:"#2E2D27", inkFade:"#4A483F",
  matcha:"#4A6741", matchaMid:"#5C7A4E", matchaLight:"#7A9966",
  gold:"#B8873A", goldLight:"#D4A855",
  mist:"#8A8578", mistLight:"#ADA89E", white:"#FDFAF4",
};

const PARTNERS = [
  { icon:"🎨", name:"Webデザイン",    desc:"LP・採用ページ・バナー", color:C.matcha },
  { icon:"🖨",  name:"DTP・印刷物",   desc:"パンフ・チラシ・申請書", color:C.gold },
  { icon:"⚙",  name:"ITシステム",    desc:"kintone・GAS・VBA実装", color:C.matchaMid },
  { icon:"✏",  name:"コピーライト",  desc:"LP文章・補助金文書",     color:C.matcha },
  { icon:"🎬", name:"動画制作",      desc:"会社紹介・SNS・採用動画", color:C.gold },
  { icon:"🌐", name:"繁体字翻訳",    desc:"台湾向け提案書・資料",   color:C.matchaLight },
  { icon:"📐", name:"CAD・図面",     desc:"建設土木 図面デジタル化", color:C.inkFade },
];

const SERVICES = [
  { num:"01", title:"DX / AX コンサルティング", sub:"地域企業向け", desc:"「ITを入れる」ではなく「現場が変わる」DXを設計します。低コスト・高実装性の改善プランを提供。", icon:"⬡", color:C.matcha, partners:["Webデザイン","ITシステム"] },
  { num:"02", title:"補助金活用サポート", sub:"持続化・IT導入・ものづくり", desc:"補助金の特定から申請準備まで伴走。制度適合性の確認・書類構成・スケジュール管理を一括サポート。", icon:"◈", color:C.gold, partners:["コピーライト","DTP・印刷物"] },
  { num:"03", title:"建設・土木向け業務改善", sub:"施工管理から受注まで", desc:"建設土木現場の非効率を可視化し、受注率向上・書類削減・情報共有強化の具体策を提案します。", icon:"◧", color:C.matchaMid, partners:["CAD・図面","ITシステム"] },
  { num:"04", title:"物流バックオフィス支援", sub:"外部委託型", desc:"配車・帳票・情報共有業務を外部から支援。Teams/SharePointを活用したデジタル連絡板も対応。", icon:"◫", color:C.inkFade, partners:["ITシステム"] },
  { num:"05", title:"医療コンサル協業支援", sub:"医療機関向け", desc:"医療コンサル企業との協業体制のもと、経営改善・業務標準化・補助金活用を複合的に支援します。", icon:"◉", color:C.matcha, partners:["コピーライト","Webデザイン"] },
  { num:"06", title:"BCP対策 資料作成サポート", sub:"事業継続計画", desc:"自然災害・感染症・システム障害に備えたBCP文書の整備をサポート。初動対応・連絡体制の文書化まで。", icon:"◎", color:C.gold, partners:["DTP・印刷物","コピーライト"] },
  { num:"07", title:"台湾企業 日本進出支援", sub:"日台ビジネス連携", desc:"繁体字中国語対応・台湾ネットワークを活かし、TSMC/JASM熊本進出に連動するビジネス機会を橋渡し。", icon:"◐", color:C.matchaLight, partners:["繁体字翻訳","Webデザイン"] },
  { num:"08", title:"製造業向け 生産性改善支援", sub:"工場・製造現場向け", desc:"生産現場の非効率・属人化・品質管理の課題を整理し、現場に即した改善策を提案。受発注・工程管理のデジタル化、補助金活用による設備投資支援も対応します。", icon:"◩", color:C.gold, partners:["ITシステム","DTP・印刷物"] },
];

const PHILOSOPHY = [
  { kanji:"手段", title:"デジタルは手段である", body:"DXやデジタルツールは経営成果・現場改善のための道具です。技術を入れることが目的化した瞬間、現場は疲弊します。YOHAKU Lab.は常に「何のために」から設計します。", accent:C.matcha },
  { kanji:"自律", title:"依存させない", body:"クライアントを丸投げ・依存の構造に置きません。「自分でできる」状態を目指して、知識・仕組み・習慣をともに作ります。", accent:C.gold },
  { kanji:"余白", title:"次の一手を考える時間", body:"「余白（YOHAKU）」とは、次の戦略を考えるための時間です。業務改善によって生まれた時間を、経営者が本来すべきことへ使える環境を設計します。", accent:C.matchaLight },
];

const FLOW = [
  { step:"01", title:"無料ヒアリング", desc:"現状課題・ご要望を1時間程度でお聞きします。オンライン・訪問どちらも対応。", icon:"☎" },
  { step:"02", title:"診断・提案書", desc:"課題の優先順位・提案内容・費用感・KPIを文書化してご提示します。", icon:"📋" },
  { step:"03", title:"契約・着手", desc:"月額定額型・プロジェクト型からお選びいただき、速やかに着手します。", icon:"✍" },
  { step:"04", title:"伴走・定着", desc:"実装後の定着まで責任を持って支援。依存ではなく自律を目指します。", icon:"🌱" },
];

function useWindowWidth() {
  const [w, setW] = useState(typeof window !== "undefined" ? window.innerWidth : 768);
  useEffect(() => { const h=()=>setW(window.innerWidth); window.addEventListener("resize",h); return()=>window.removeEventListener("resize",h); }, []);
  return w;
}

function useInView(t=0.08) {
  const ref=useRef(null); const [v,setV]=useState(false);
  useEffect(()=>{ const o=new IntersectionObserver(([e])=>{if(e.isIntersecting)setV(true);},{threshold:t}); if(ref.current)o.observe(ref.current); return()=>o.disconnect(); },[]);
  return [ref,v];
}

function FadeIn({children,delay=0,style={}}){
  const [ref,v]=useInView();
  return <div ref={ref} style={{opacity:v?1:0,transform:v?"translateY(0)":"translateY(20px)",transition:`opacity .7s ease ${delay}s,transform .7s ease ${delay}s`,...style}}>{children}</div>;
}

function Tag({text,light}){
  return <span style={{display:"inline-block",border:`1px solid ${C.gold}`,color:light?C.goldLight:C.gold,fontSize:9,letterSpacing:"0.28em",padding:"3px 10px"}}>{text}</span>;
}

function SectionHead({tag,title,light=false,sub}){
  return <FadeIn><div style={{display:"flex",alignItems:"flex-start",gap:14,marginBottom:40}}>
    <div style={{width:2,height:50,background:light?C.gold:C.matcha,marginTop:6,flexShrink:0}}/>
    <div>
      <Tag text={tag} light={light}/>
      <h2 style={{fontSize:"clamp(22px,5vw,40px)",fontWeight:300,marginTop:10,letterSpacing:"0.04em",color:light?C.washi:C.ink}}>{title}</h2>
      {sub && <p style={{fontSize:13,color:light?"rgba(244,239,228,.5)":C.mist,marginTop:8,lineHeight:1.7}}>{sub}</p>}
    </div>
  </div></FadeIn>;
}

function scrollTo(id){document.getElementById(id)?.scrollIntoView({behavior:"smooth"});}

export default function App(){
  const width=useWindowWidth();
  const isMobile=width<768;
  const [scrolled,setScrolled]=useState(false);
  const [menuOpen,setMenuOpen]=useState(false);
  const [activeSection,setActiveSection]=useState("");
  const [hoveredPartner,setHoveredPartner]=useState(null);

  useEffect(()=>{
    const fn=()=>{
      setScrolled(window.scrollY>50);
      for(const s of["contact","about","services","network","philosophy"].reverse()){
        const el=document.getElementById(s);
        if(el&&window.scrollY>=el.offsetTop-100){setActiveSection(s);return;}
      }
      setActiveSection("");
    };
    window.addEventListener("scroll",fn); return()=>window.removeEventListener("scroll",fn);
  },[]);
  useEffect(()=>{if(!isMobile)setMenuOpen(false);},[isMobile]);

  const navActive=scrolled||menuOpen;
  const px=isMobile?"20px":"clamp(40px,7vw,100px)";
  const sp=isMobile?"68px 20px":"88px clamp(40px,7vw,100px)";
  const handleNav=(href)=>{setMenuOpen(false);setTimeout(()=>scrollTo(href),60);};

  return (
    <div style={{background:C.washi,color:C.ink,fontFamily:"'Hiragino Mincho ProN','Yu Mincho','Noto Serif JP',Georgia,serif",overflowX:"hidden"}}>
    <style>{`
      *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
      html{scroll-behavior:smooth;-webkit-text-size-adjust:100%;}
      body{-webkit-font-smoothing:antialiased;}
      ::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:${C.matcha};border-radius:2px;}
      @keyframes reveal{from{opacity:0;transform:translateY(32px);}to{opacity:1;transform:translateY(0);}}
      @keyframes floatY{0%,100%{transform:translateY(0);}50%{transform:translateY(-14px);}}
      @keyframes spin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
      @keyframes pulse{0%,100%{opacity:0.3;}50%{opacity:0.8;}}
      @keyframes slideDown{from{opacity:0;transform:translateY(-6px);}to{opacity:1;transform:translateY(0);}}
      @keyframes orbitSpin{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
      .btn{transition:opacity .2s,transform .15s;cursor:pointer;-webkit-tap-highlight-color:transparent;}
      .btn:hover{opacity:.88;transform:translateY(-2px);}.btn:active{transform:scale(.97);}
      .card{transition:transform .25s,box-shadow .25s;}
      .card:hover{transform:translateY(-3px);box-shadow:0 10px 28px rgba(0,0,0,.12);}
      .partner-pill{transition:all .2s ease;cursor:default;}
      .partner-pill:hover{transform:translateY(-2px);}
      a{-webkit-tap-highlight-color:transparent;}
    `}</style>

    {/* NAV */}
    <nav style={{position:"fixed",top:0,left:0,right:0,zIndex:300,background:navActive?"rgba(244,239,228,.97)":"transparent",backdropFilter:navActive?"blur(16px)":"none",borderBottom:navActive?"1px solid rgba(0,0,0,.07)":"none",transition:"all .35s ease"}}>
      <div style={{height:60,display:"flex",alignItems:"center",justifyContent:"space-between",padding:`0 ${px}`}}>
        <div onClick={()=>window.scrollTo({top:0,behavior:"smooth"})} style={{cursor:"pointer"}}>
          <div style={{fontSize:isMobile?15:17,letterSpacing:"0.22em",color:C.ink}}>YOHAKU <span style={{color:C.matcha}}>Lab.</span></div>
          <div style={{fontSize:8,letterSpacing:"0.2em",color:C.mist,marginTop:2}}>山口 剛 / 熊本県大津町</div>
        </div>
        {!isMobile && (
          <div style={{display:"flex",alignItems:"center",gap:24}}>
            {[{l:"哲学",h:"philosophy"},{l:"サービス",h:"services"},{l:"支援体制",h:"network"},{l:"代表",h:"about"},{l:"お問い合わせ",h:"contact"}].map(({l,h})=>(
              <span key={h} onClick={()=>scrollTo(h)} style={{cursor:"pointer",fontSize:13,letterSpacing:"0.1em",color:activeSection===h?C.matcha:C.inkFade,transition:"color .2s"}}>{l}</span>
            ))}
            <button className="btn" onClick={()=>scrollTo("contact")} style={{background:C.matcha,color:C.white,border:"none",padding:"8px 18px",fontSize:12,letterSpacing:"0.1em",fontFamily:"inherit",borderRadius:2,cursor:"pointer"}}>無料相談</button>
          </div>
        )}
        {isMobile && (
          <button onClick={()=>setMenuOpen(o=>!o)} style={{background:"none",border:"none",cursor:"pointer",display:"flex",flexDirection:"column",gap:5,padding:"10px 8px",color:C.ink}} aria-label="メニュー">
            {[0,1,2].map(i=>(
              <span key={i} style={{display:"block",width:22,height:1.5,background:"currentColor",transition:"all .3s ease",transformOrigin:"center",
                transform:menuOpen?(i===0?"rotate(45deg) translate(4.5px,4.5px)":i===1?"scaleX(0)":"rotate(-45deg) translate(4.5px,-4.5px)"):"none",
                opacity:menuOpen&&i===1?0:1}}/>
            ))}
          </button>
        )}
      </div>
      {isMobile&&menuOpen&&(
        <div style={{animation:"slideDown .22s ease",background:"rgba(244,239,228,.99)",borderTop:"1px solid rgba(0,0,0,.05)"}}>
          {[{l:"哲学",h:"philosophy"},{l:"サービス",h:"services"},{l:"支援体制",h:"network"},{l:"代表について",h:"about"},{l:"お問い合わせ",h:"contact"}].map(({l,h})=>(
            <div key={h} onClick={()=>handleNav(h)} style={{padding:"16px 24px",fontSize:15,letterSpacing:"0.1em",color:activeSection===h?C.matcha:C.inkFade,cursor:"pointer",borderBottom:"1px solid rgba(0,0,0,.04)",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              {l}<span style={{color:C.mist,fontSize:12}}>→</span>
            </div>
          ))}
          <div style={{padding:"14px 20px 20px"}}>
            <button className="btn" onClick={()=>handleNav("contact")} style={{width:"100%",background:C.matcha,color:C.white,border:"none",padding:"15px",fontSize:14,letterSpacing:"0.12em",fontFamily:"inherit",borderRadius:3,cursor:"pointer"}}>無料相談を申し込む</button>
          </div>
        </div>
      )}
    </nav>

    {/* HERO */}
    <section style={{minHeight:"100svh",background:C.ink,position:"relative",display:"flex",alignItems:"center",overflow:"hidden",paddingTop:60}}>
      <div style={{position:"absolute",right:isMobile?"-8%":"-2%",top:"50%",transform:"translateY(-50%)",fontSize:isMobile?"clamp(130px,52vw,200px)":"clamp(220px,28vw,400px)",lineHeight:1,fontWeight:900,fontFamily:"'Hiragino Sans','Yu Gothic',sans-serif",color:"rgba(255,255,255,.03)",userSelect:"none",pointerEvents:"none",animation:"floatY 10s ease-in-out infinite"}}>余白</div>
      {[20,40,60,80].map((l,i)=><div key={i} style={{position:"absolute",top:0,bottom:0,left:`${l}%`,width:1,background:`rgba(255,255,255,${.01+i*.005})`,pointerEvents:"none"}}/>)}
      {!isMobile&&<div style={{position:"absolute",top:"10%",right:"7%",width:90,height:90,borderRadius:"50%",border:"1px solid rgba(196,153,58,.18)",animation:"spin 24s linear infinite"}}><div style={{position:"absolute",inset:12,borderRadius:"50%",border:"1px dashed rgba(196,153,58,.11)"}}/></div>}

      <div style={{position:"relative",zIndex:1,padding:isMobile?"0 24px":`0 ${px}`,maxWidth:860}}>
        <div style={{animation:"reveal .9s ease .1s both"}}><Tag text="2026.6.21 始動" light/></div>
        <div style={{animation:"reveal .9s ease .28s both",marginTop:22}}>
          <h1 style={{fontSize:isMobile?"clamp(32px,10vw,50px)":"clamp(44px,6.5vw,72px)",fontWeight:300,lineHeight:1.3,color:C.white,letterSpacing:"0.03em"}}>
            仕事を増やす前に、<br/><span style={{color:C.matchaLight}}>余白を増やす。</span>
          </h1>
        </div>
        <div style={{animation:"reveal .9s ease .44s both",marginTop:18,maxWidth:520}}>
          <p style={{fontSize:isMobile?13:15,lineHeight:2,color:"rgba(244,239,228,.58)",letterSpacing:"0.05em"}}>
            DX・AX・補助金活用・業務改善を通じて、地域の中小企業に「次の一手を考える時間」を届けます。<br/>
            <span style={{color:"rgba(244,239,228,.45)",fontSize:isMobile?12:13}}>デザイン・IT実装・翻訳まで、専門パートナーネットワークとの連携でワンストップ対応。</span>
          </p>
        </div>
        <div style={{animation:"reveal .9s ease .6s both",marginTop:32,display:"flex",flexDirection:isMobile?"column":"row",gap:12}}>
          <button className="btn" onClick={()=>scrollTo("contact")} style={{background:`linear-gradient(135deg,${C.matcha},${C.matchaLight})`,color:C.white,border:"none",padding:isMobile?"16px 20px":"14px 32px",fontSize:isMobile?15:14,letterSpacing:"0.12em",fontFamily:"inherit",borderRadius:3,cursor:"pointer"}}>無料相談を申し込む</button>
          <button className="btn" onClick={()=>scrollTo("network")} style={{background:"transparent",color:"rgba(244,239,228,.65)",border:"1px solid rgba(244,239,228,.18)",padding:isMobile?"15px 20px":"14px 24px",fontSize:13,letterSpacing:"0.1em",fontFamily:"inherit",borderRadius:3,cursor:"pointer"}}>支援体制を見る ↓</button>
        </div>
        <div style={{animation:"reveal .9s ease .76s both",marginTop:44,paddingTop:24,borderTop:"1px solid rgba(255,255,255,.07)",display:"flex",gap:isMobile?24:40,flexWrap:"wrap"}}>
          {[["8","サービス領域"],["7+","専門パートナー"],["日・中","二言語対応"]].map(([v,l])=>(
            <div key={l}><div style={{fontSize:isMobile?20:24,color:C.goldLight,fontWeight:300,letterSpacing:"0.04em"}}>{v}</div><div style={{fontSize:9,color:"rgba(244,239,228,.36)",letterSpacing:"0.14em",marginTop:3}}>{l}</div></div>
          ))}
        </div>
      </div>
      <div style={{position:"absolute",bottom:20,left:"50%",transform:"translateX(-50%)",display:"flex",flexDirection:"column",alignItems:"center",gap:5,color:"rgba(255,255,255,.2)",fontSize:8,letterSpacing:"0.2em",animation:"pulse 2.5s ease-in-out infinite",pointerEvents:"none"}}>
        <span>SCROLL</span><div style={{width:1,height:28,background:"rgba(255,255,255,.14)"}}/>
      </div>
    </section>

    {/* PHILOSOPHY */}
    <section id="philosophy" style={{background:C.washi,padding:sp}}>
      <SectionHead tag="PHILOSOPHY" title="YOHAKU の哲学"/>
      <div style={{display:"grid",gridTemplateColumns:isMobile?"1fr":"repeat(3,1fr)",gap:isMobile?10:2}}>
        {PHILOSOPHY.map((p,i)=>(
          <FadeIn key={p.kanji} delay={isMobile?0:i*.12}>
            <div style={{background:i%2===1?C.washiDark:C.washi,padding:isMobile?"28px 22px":"40px 30px",borderTop:`3px solid ${p.accent}`,position:"relative",overflow:"hidden",height:"100%"}}>
              <div style={{position:"absolute",right:8,top:2,fontSize:isMobile?52:68,lineHeight:1,color:"rgba(0,0,0,.04)",fontFamily:"'Hiragino Sans',sans-serif",fontWeight:900,userSelect:"none"}}>{p.kanji}</div>
              <div style={{position:"relative",zIndex:1}}>
                <div style={{fontSize:9,color:C.mist,letterSpacing:"0.22em",marginBottom:12}}>0{i+1}</div>
                <h3 style={{fontSize:isMobile?16:18,fontWeight:400,letterSpacing:"0.05em",marginBottom:14}}>{p.title}</h3>
                <p style={{fontSize:13,lineHeight:2,color:C.inkFade,letterSpacing:"0.02em"}}>{p.body}</p>
              </div>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>

    {/* SERVICES */}
    <section id="services" style={{background:C.inkLight,padding:sp}}>
      <SectionHead tag="SERVICES" title="サービス一覧" light sub="各サービスに専門パートナーが連携し、コンサルから実装・納品まで一貫対応します"/>
      <p style={{fontSize:11,color:C.mistLight,marginTop:-28,marginBottom:24,letterSpacing:"0.04em"}}>※ 行政書士・社労士・税理士等の独占業務は対象外です</p>
      <div style={{display:"grid",gridTemplateColumns:isMobile?"1fr":"repeat(auto-fill,minmax(250px,1fr))",gap:10}}>
        {SERVICES.map((s,i)=>(
          <FadeIn key={s.num} delay={isMobile?0:(i%3)*.07}>
            <div className="card" style={{background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.07)",borderTop:`2px solid ${s.color}`,borderRadius:4,padding:isMobile?"20px 18px":"26px 20px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                <span style={{fontSize:9,color:C.mistLight,letterSpacing:"0.2em"}}>{s.num}</span>
                <span style={{fontSize:18,color:s.color,opacity:.65}}>{s.icon}</span>
              </div>
              <div style={{fontSize:9,color:s.color,letterSpacing:"0.15em",marginBottom:6}}>{s.sub}</div>
              <h3 style={{fontSize:14,fontWeight:400,color:C.washi,letterSpacing:"0.03em",lineHeight:1.65,marginBottom:10}}>{s.title}</h3>
              <p style={{fontSize:12,color:C.mistLight,lineHeight:1.85,marginBottom:12}}>{s.desc}</p>
              {/* Partner tags */}
              <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                {s.partners.map(p=>(
                  <span key={p} style={{fontSize:10,padding:"2px 8px",background:"rgba(92,122,78,.18)",border:"1px solid rgba(92,122,78,.3)",color:C.matchaLight,borderRadius:2,letterSpacing:"0.05em"}}>
                    {p}
                  </span>
                ))}
              </div>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>

    {/* PARTNER NETWORK — new section */}
    <section id="network" style={{background:C.washi,padding:sp}}>
      <SectionHead tag="PARTNER NETWORK" title="実行パートナー体制" sub="コンサルで終わらない。デザイン・IT・翻訳・動画まで、専門パートナーと連携してワンストップで対応します。"/>

      {/* Central diagram */}
      <FadeIn>
        <div style={{position:"relative",maxWidth:600,margin:"0 auto 40px",padding:"0 16px"}}>
          <div style={{background:C.inkLight,border:`1px solid rgba(255,255,255,.08)`,borderRadius:12,padding:isMobile?"28px 16px":"36px 28px"}}>

            {/* Hub */}
            <div style={{textAlign:"center",marginBottom:28}}>
              <div style={{display:"inline-flex",alignItems:"center",justifyContent:"center",width:isMobile?80:96,height:isMobile?80:96,borderRadius:"50%",background:`linear-gradient(135deg,${C.matcha},${C.matchaMid})`,marginBottom:12}}>
                <div style={{textAlign:"center"}}>
                  <div style={{fontSize:isMobile?11:12,color:C.white,letterSpacing:"0.12em",fontWeight:500}}>YOHAKU</div>
                  <div style={{fontSize:isMobile?9:10,color:"rgba(255,255,255,.7)",letterSpacing:"0.1em"}}>Lab.</div>
                </div>
              </div>
              <div style={{fontSize:11,color:C.mist,letterSpacing:"0.15em"}}>統括PM・品質管理・クライアント対応</div>
            </div>

            {/* Arrow */}
            <div style={{display:"flex",justifyContent:"center",marginBottom:16}}>
              <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
                <div style={{width:1,height:24,background:`rgba(92,122,78,.5)`}}/>
                <div style={{fontSize:10,color:C.matchaLight,letterSpacing:"0.1em"}}>専門パートナーと連携</div>
                <div style={{width:1,height:24,background:`rgba(92,122,78,.5)`}}/>
              </div>
            </div>

            {/* Partner grid */}
            <div style={{display:"grid",gridTemplateColumns:`repeat(${isMobile?2:4},1fr)`,gap:8}}>
              {PARTNERS.map((p,i)=>(
                <div key={p.name} className="partner-pill"
                  onMouseEnter={()=>setHoveredPartner(i)}
                  onMouseLeave={()=>setHoveredPartner(null)}
                  style={{
                    background:hoveredPartner===i?`rgba(92,122,78,.2)`:"rgba(255,255,255,.05)",
                    border:`1px solid ${hoveredPartner===i?"rgba(92,122,78,.5)":"rgba(255,255,255,.1)"}`,
                    borderRadius:6,padding:"12px 8px",textAlign:"center",
                  }}>
                  <div style={{fontSize:isMobile?18:20,marginBottom:6}}>{p.icon}</div>
                  <div style={{fontSize:11,fontWeight:500,color:C.washi,letterSpacing:"0.03em",marginBottom:3}}>{p.name}</div>
                  <div style={{fontSize:10,color:C.mist,lineHeight:1.4}}>{p.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </FadeIn>

      {/* 3 strengths */}
      <div style={{display:"grid",gridTemplateColumns:isMobile?"1fr":"repeat(3,1fr)",gap:isMobile?12:16}}>
        {[
          { accent:C.matcha, title:"コンサルで終わらない", body:"提案書を渡して終わりではなく、Webデザイン・IT実装・印刷物まで、実際の成果物を届けます。"},
          { accent:C.gold,   title:"固定費ゼロの柔軟体制", body:"案件ごとに最適なパートナーを組み合わせ。雇用なしで多領域に対応できるため、低コストで提供可能。"},
          { accent:C.matchaLight, title:"品質は山口が保証", body:"外注先の選定・中間確認・最終チェックをYOHAKU Lab.が一手に担い、納品品質を責任持って管理します。"},
        ].map((item,i)=>(
          <FadeIn key={i} delay={isMobile?0:i*.1}>
            <div style={{borderTop:`3px solid ${item.accent}`,background:C.washiDark,padding:"28px 24px"}}>
              <h3 style={{fontSize:15,fontWeight:400,letterSpacing:"0.04em",marginBottom:14}}>{item.title}</h3>
              <p style={{fontSize:13,color:C.inkFade,lineHeight:1.9}}>{item.body}</p>
            </div>
          </FadeIn>
        ))}
      </div>
    </section>

    {/* ABOUT */}
    <section id="about" style={{background:C.inkLight,padding:sp}}>
      <SectionHead tag="ABOUT" title="代表について" light/>
      <div style={{display:"grid",gridTemplateColumns:isMobile?"1fr":"1fr 1fr",gap:isMobile?20:44,alignItems:"start"}}>
        <FadeIn>
          <div>
            <div style={{background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.07)",padding:isMobile?"24px 20px":"28px 24px",marginBottom:14}}>
              <div style={{fontSize:9,letterSpacing:"0.25em",color:C.mist,marginBottom:16}}>PROFILE</div>
              <div style={{fontSize:isMobile?22:26,fontWeight:300,letterSpacing:"0.06em",marginBottom:3,color:C.washi}}>山口 剛</div>
              <div style={{fontSize:11,color:C.mist,letterSpacing:"0.12em",marginBottom:18}}>Yamaguchi Go</div>
              <div style={{height:1,background:"rgba(255,255,255,.08)",marginBottom:18}}/>
              {[["拠点","熊本県菊池郡大津町"],["活動域","大津町・熊本市・TSMC周辺"],["言語","日本語・繁体字中国語"],["所属","大津町企業連絡協議会 / あけぼの会"]].map(([k,v])=>(
                <div key={k} style={{display:"flex",gap:12,fontSize:12,marginBottom:10}}>
                  <span style={{color:C.mist,width:40,flexShrink:0,paddingTop:1}}>{k}</span>
                  <span style={{color:C.mistLight,lineHeight:1.7}}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{background:"rgba(92,122,78,.12)",border:"1px solid rgba(92,122,78,.25)",padding:"18px 20px",marginBottom:14}}>
              <div style={{fontSize:9,letterSpacing:"0.22em",color:C.goldLight,marginBottom:10}}>PARTNER</div>
              <div style={{fontSize:14,color:C.washi,marginBottom:4}}>ソルクリエイト（Solcreate）</div>
              <div style={{fontSize:10,color:"rgba(244,239,228,.42)",marginBottom:10}}>熊本市北区楠木 / 2026年4月法人化</div>
              <p style={{fontSize:12,color:"rgba(244,239,228,.55)",lineHeight:1.8}}>書類作成・補助金支援・業務標準化において協業。複数の専門性を組み合わせた複合提案を実現します。</p>
            </div>
            <div style={{background:"rgba(196,153,58,.1)",border:"1px solid rgba(196,153,58,.25)",padding:"18px 20px",marginBottom:14}}>
              <div style={{fontSize:9,letterSpacing:"0.22em",color:C.goldLight,marginBottom:10}}>PARTNER</div>
              <div style={{fontSize:14,color:C.washi,marginBottom:4}}>カダブラ株式会社</div>
              <div style={{fontSize:10,color:"rgba(244,239,228,.42)",marginBottom:10}}>熊本エリア ビジネス開発パートナー</div>
              <p style={{fontSize:12,color:"rgba(244,239,228,.55)",lineHeight:1.8}}>熊本エリアの営業・事業開発において業務提携。地域企業への販路開拓・新規事業推進を共同で支援します。</p>
            </div>
            <div style={{background:"rgba(196,153,58,.08)",border:"1px solid rgba(196,153,58,.2)",padding:"16px 20px"}}>
              <div style={{fontSize:9,letterSpacing:"0.22em",color:C.goldLight,marginBottom:8}}>SPECIALIST NETWORK</div>
              <p style={{fontSize:12,color:"rgba(244,239,228,.55)",lineHeight:1.8}}>Webデザイン・IT実装・コピーライト・動画・繁体字翻訳・CAD図面の各専門フリーランスパートナーとの連携体制を構築。案件ごとに最適な体制を編成します。</p>
            </div>
          </div>
        </FadeIn>
        <FadeIn delay={isMobile?0:.18}>
          <div style={{display:"flex",flexDirection:"column",gap:24}}>
            {[
              {b:C.matcha,t:"物流会社の営業所長として\n現場の「本音」を知る",d:"物流会社の営業所長として長年、業務改善・人材管理・顧客対応に携わってきました。「現場で使えない理論は提案しない」という信念は、この経験から来ています。"},
              {b:C.gold,t:"TSMC熊本進出と\n台湾ネットワークを繋ぐ",d:"台湾とのネットワーク・繁体字中国語対応を背景に、JASM/TSMC熊本進出に伴うビジネス機会を地域中小企業と連携させるブリッジ役を担います。"},
              {b:C.matchaLight,t:"専門ネットワークで\n地方コンサルの常識を変える",d:"デザイン・IT実装・翻訳・動画など各分野の専門パートナーと連携することで、大手コンサルに匹敵する提案品質と実装力を、地域密着の価格で提供します。"},
            ].map((item,i)=>(
              <div key={i} style={{borderLeft:`2px solid ${item.b}`,paddingLeft:20}}>
                <h3 style={{fontSize:isMobile?14:16,fontWeight:400,letterSpacing:"0.04em",marginBottom:10,lineHeight:1.7,color:C.washi,whiteSpace:"pre-line"}}>{item.t}</h3>
                <p style={{fontSize:12,color:C.mistLight,lineHeight:2}}>{item.d}</p>
              </div>
            ))}
          </div>
        </FadeIn>
      </div>
    </section>

    {/* FLOW */}
    <section style={{background:C.washiDark,padding:sp}}>
      <FadeIn><div style={{textAlign:"center",marginBottom:40}}><Tag text="FLOW"/><h2 style={{fontSize:"clamp(20px,4vw,32px)",fontWeight:300,marginTop:10,letterSpacing:"0.06em"}}>ご相談の流れ</h2></div></FadeIn>
      {isMobile?(
        <div style={{display:"flex",flexDirection:"column",maxWidth:480,margin:"0 auto"}}>
          {FLOW.map((f,i)=>(
            <FadeIn key={f.step}><div>
              <div style={{background:i%2===0?C.washi:C.washiDark,padding:"22px 20px",display:"flex",gap:16,alignItems:"flex-start"}}>
                <div style={{width:44,height:44,borderRadius:"50%",flexShrink:0,background:i===0?C.matcha:"rgba(0,0,0,.07)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{f.icon}</div>
                <div><div style={{fontSize:8,color:C.mist,letterSpacing:"0.22em",marginBottom:5}}>STEP {f.step}</div><h3 style={{fontSize:14,fontWeight:400,letterSpacing:"0.05em",marginBottom:7}}>{f.title}</h3><p style={{fontSize:12,color:C.inkFade,lineHeight:1.85}}>{f.desc}</p></div>
              </div>
              {i<3&&<div style={{display:"flex",justifyContent:"center",padding:"6px 0"}}><div style={{width:26,height:26,background:C.matcha,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:C.white,fontSize:11}}>↓</div></div>}
            </div></FadeIn>
          ))}
        </div>
      ):(
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)"}}>
          {FLOW.map((f,i)=>(
            <FadeIn key={f.step} delay={i*.1}><div style={{background:i%2===0?C.washi:C.washiDark,padding:"28px 20px",borderTop:i===0?`3px solid ${C.matcha}`:"3px solid transparent",position:"relative",height:"100%"}}>
              {i<3&&<div style={{position:"absolute",right:-13,top:"50%",transform:"translateY(-50%)",width:26,height:26,background:C.matcha,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:C.white,fontSize:10,zIndex:2}}>→</div>}
              <div style={{fontSize:24,marginBottom:10}}>{f.icon}</div>
              <div style={{fontSize:9,color:C.mist,letterSpacing:"0.2em",marginBottom:6}}>STEP {f.step}</div>
              <h3 style={{fontSize:13,fontWeight:400,letterSpacing:"0.05em",marginBottom:8}}>{f.title}</h3>
              <p style={{fontSize:12,color:C.inkFade,lineHeight:1.85}}>{f.desc}</p>
            </div></FadeIn>
          ))}
        </div>
      )}
    </section>

    {/* CONTACT */}
    <section id="contact" style={{background:C.ink,padding:sp}}>
      <div style={{maxWidth:580,margin:"0 auto"}}>
        <FadeIn><div style={{textAlign:"center",marginBottom:44}}>
          <Tag text="CONTACT" light/>
          <h2 style={{fontSize:isMobile?"clamp(22px,7vw,34px)":"clamp(26px,5vw,42px)",fontWeight:300,marginTop:14,letterSpacing:"0.04em",color:C.washi}}>まずは話してみませんか</h2>
          <p style={{fontSize:13,color:"rgba(244,239,228,.45)",marginTop:14,lineHeight:2,letterSpacing:"0.04em"}}>初回ヒアリングは無料です。<br/>「なんとなく困っている」からでも大丈夫です。</p>
        </div></FadeIn>
        <FadeIn delay={.1}><div style={{display:"flex",flexDirection:"column",gap:12}}>
          <a href="tel:090-2505-7937" className="btn" style={{display:"flex",alignItems:"center",justifyContent:"center",gap:12,background:`linear-gradient(135deg,${C.matcha},${C.matchaLight})`,color:C.white,textDecoration:"none",padding:isMobile?"20px 16px":"22px",borderRadius:4,fontSize:isMobile?22:24,letterSpacing:"0.08em",minHeight:68,fontFamily:"inherit"}}>
            <span style={{fontSize:22}}>📞</span>090-2505-7937
          </a>
          <a href="mailto:yamaguchi.g5167@gmail.com" className="btn" style={{display:"flex",alignItems:"center",justifyContent:"center",gap:10,flexWrap:"wrap",background:"rgba(255,255,255,.05)",border:"1px solid rgba(255,255,255,.12)",color:"rgba(244,239,228,.72)",textDecoration:"none",padding:"16px 16px",borderRadius:4,fontSize:isMobile?13:14,minHeight:54,textAlign:"center",wordBreak:"break-all",fontFamily:"inherit"}}>
            <span style={{fontSize:16,flexShrink:0}}>✉</span>yamaguchi.g5167@gmail.com
          </a>
        </div></FadeIn>
        <FadeIn delay={.2}><div style={{marginTop:36,display:"grid",gridTemplateColumns:isMobile?"1fr 1fr":"repeat(3,1fr)",gap:10}}>
          {[["📍","拠点","熊本県大津町"],["🕐","受付時間","平日 9:00〜18:00"],["🌐","対応範囲","熊本全域・全国オンライン"]].map(([icon,label,val])=>(
            <div key={label} style={{textAlign:"center",background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.06)",borderRadius:4,padding:"14px 10px"}}>
              <div style={{fontSize:18,marginBottom:6}}>{icon}</div>
              <div style={{fontSize:8,color:C.mist,letterSpacing:"0.15em",marginBottom:5}}>{label}</div>
              <div style={{fontSize:11,color:"rgba(244,239,228,.5)",lineHeight:1.6}}>{val}</div>
            </div>
          ))}
        </div></FadeIn>
      </div>
    </section>

    {/* FOOTER */}
    <footer style={{background:"#0f0f0d",padding:isMobile?"24px 20px":"24px clamp(40px,7vw,100px)",display:"flex",flexDirection:isMobile?"column":"row",justifyContent:"space-between",alignItems:isMobile?"flex-start":"center",gap:8}}>
      <div>
        <div style={{fontSize:14,letterSpacing:"0.22em",color:"rgba(244,239,228,.5)"}}>YOHAKU <span style={{color:C.matcha}}>Lab.</span></div>
        <div style={{fontSize:8,color:"rgba(244,239,228,.2)",letterSpacing:"0.14em",marginTop:3}}>山口 剛 / 熊本県菊池郡大津町</div>
      </div>
      <div style={{fontSize:9,color:"rgba(244,239,228,.16)",letterSpacing:"0.08em"}}>© 2026 YOHAKU Lab. All rights reserved.</div>
    </footer>
    </div>
  );
}
